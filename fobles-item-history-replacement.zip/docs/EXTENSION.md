# Fobles for Sitecore

Chrome and Edge extension that adds keyboard shortcuts and navigation helpers for Sitecore editors.

## Development Setup

From the project root:

```text
npm install
npm run build:extension
```

To run Sitecore browser tests, copy `fobles.environments.example.json` to
`fobles.environments.json` and set your own test environment. Real endpoints and
credentials must remain in the ignored `fobles.environments.json` file (and the DPAPI-backed
secure secret store for passwords - see `npm run secret:set`).

To run the browser tests, install the Playwright browsers once:

```text
npx playwright install
```

## Load Unpacked

1. Open `edge://extensions` or `chrome://extensions`.
2. Enable **Developer mode**.
3. Select **Load unpacked**.
4. Choose the `dist/unpacked/` folder.

After changing source files, run `npm run build:extension`, then select **Reload** for the extension and refresh affected Sitecore tabs.

## Source Layout

- `src/content/`: content-script source (injected into Sitecore pages), including its own `features/`, `styles/`, and `toolbar/`.
- `src/background/`: MV3 service worker source.
- `src/options/`: "Additional Settings" page logic.
- `src/popup/`: toolbar-icon popup logic.
- `src/shared/`: code used by more than one surface.
- `src/public/`: maintained manifest, options/popup HTML shells, and icon asset.
- `dist/unpacked/`: generated browser package loaded by the browser.
- `tests/e2e/`: Playwright browser integration tests.

## Testing

```text
npm run test:e2e
```

Use VS Code's Playwright test runner to run or debug individual tests and suites.

See [tests/README.md](../tests/README.md) for setup details and the Sitecore test login troubleshooting note.

## Usage

- **Ctrl+Shift+E** (or **Cmd+Shift+E** on Mac): Toggle Fobles on or off.
- Select **AI Pages mappings** from the extension popup to map Sitecore content roots to AI Pages.

### AI Pages Jump

Add one group per Sitecore account, then map that group's content roots to AI Pages sites. A group stores the organization and tenant name; each site root stores its Content Editor path and AI Pages site.

For example:

```text
Organization: org_Ab12Cd34Ef56
Tenant name: tenant_Ab12Cd34Ef56
Root: /sitecore/content/ExampleTenant/example-site-123
Site: example-site-123
```

The **AI Pages** Jump action uses the active Content Editor item's ID, path, language, and version. When multiple roots match an item path, the most specific root is used.
